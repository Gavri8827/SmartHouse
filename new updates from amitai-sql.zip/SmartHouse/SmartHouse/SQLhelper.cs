﻿using System;
using System.Collections.Generic;
using System.Text;
using SQLite;
using System.Threading.Tasks;
using SmartHouse.familyClass.childrenTasks;
using SmartHouse.familyClass.petInfo;
using SmartHouse.shopcClass;
using SmartHouse.familyClass.childrenInfo;


namespace SmartHouse
{
    public class SQLhelper
    {
        private readonly SQLiteAsyncConnection db;

        public SQLhelper(string dbPath)
        {
            db = new SQLiteAsyncConnection(dbPath);

            db.CreateTableAsync<ChildrenInfo>();
            db.CreateTableAsync<ChildrenTasks>();
            db.CreateTableAsync<ShopListInfo>();

        }
               

        public Task<int> CreateChildrenInfo(ChildrenInfo Ct)
        {
            return db.InsertAsync(Ct);

        }
    public Task<List<ChildrenInfo>> readChildrenInfo()
        {
            return db.Table<ChildrenInfo>().ToListAsync();

        }

    public Task <int> UpdateCChildrenInfo(ChildrenInfo Ct)
        {
            return db.UpdateAsync(Ct);

        }
    public Task <int> DeletChildrenInfo(ChildrenInfo Ct) { 
        
            return db.DeleteAsync(Ct);
        }
        /// from here it the task place>
        public Task<int> CreateChildrenTask(ChildrenTasks Ct)
        {
            return db.InsertAsync(Ct);

        }
        public Task<List<ChildrenTasks>> GetTasksByChildAsync(string childName)
        {
           return db.Table<ChildrenTasks>().Where(t => t.ChildName == childName).ToListAsync();
        }
    

       
        public Task<int> DeletChildrenTask(ChildrenTasks Ct)
        {

            return db.DeleteAsync(Ct);
        }

        public Task<int> DeleteChildrenTaskByDescription(string description)
        {
            return db.Table<ChildrenTasks>()
                     .Where(t => t.Description == description)
                     .DeleteAsync();
        }

        /// form here its the shoping place

        public Task<int> CreateShopList(ShopListInfo Ct)
        {
            return db.InsertAsync(Ct);

        }
        public Task<List<ShopListInfo>> GetShopList()
        {
            return db.Table<ShopListInfo>().ToListAsync();
        }


        public Task<int> UpdateShopList(ShopListInfo Ct)
        {
            return db.UpdateAsync(Ct);

        }
        public Task<int> DeletShopList(ShopListInfo Ct)
        {

            return db.DeleteAsync(Ct);
        }




    }
}
