﻿using System;
using System.Collections.Generic;
using System.Text;

namespace SmartHouse.houseCare.professional
{
    internal class professinalnfo
    {
        public string name { get; set; }
        public string Description { get; set; }
        public string phoneNumber { get; set; }
    }
}