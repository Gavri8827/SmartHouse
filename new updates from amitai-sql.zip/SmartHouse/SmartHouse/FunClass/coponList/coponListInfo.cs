﻿using System;
using System.Collections.Generic;
using System.Text;

namespace SmartHouse.FunClass.coponListInfo
{
    internal class coponListInfo
    {
        public string Name { get; set; }

        public string MoneyAmount { get; set; }

        public string Type { get; set; }

        public string ExpirationDate { get; set; }


    }
}
