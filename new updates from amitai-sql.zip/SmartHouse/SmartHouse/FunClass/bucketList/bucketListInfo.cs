﻿using System;
using System.Collections.Generic;
using System.Text;
using Xamarin.Forms;

namespace SmartHouse.FunClass.bucketList
{
    internal class bucketListInfo
    {
        public string Description {  get; set; }

        public bool IsDune { get; set; }

        public ImageSource FunImage { get; set; }


    }
}
