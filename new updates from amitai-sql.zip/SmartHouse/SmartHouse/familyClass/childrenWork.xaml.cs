﻿using System;
using System.Collections.Generic;
using Xamarin.Forms;
using SmartHouse.familyClass.childrenInfo;
using Xamarin.Forms.Xaml;
using SmartHouse.familyClass.childrenTasks;
using Xamarin.Essentials;
using Xamarin.Forms;
using System.Collections.ObjectModel;

namespace SmartHouse.familyClass
{
    [XamlCompilation(XamlCompilationOptions.Compile)]
    public partial class childrenWork : ContentPage
    {
    
        public childrenWork()
        {
            InitializeComponent();
       
        }

        protected override async void OnAppearing()
        {
            try
            {
                base.OnAppearing();
                childrenList.ItemsSource = await App.MyDatabase.readChildrenInfo();
            }
            catch { }

        }

       

        private async void ImageWrite_Clicked(object sender, EventArgs e)
        {
            string newTask = await DisplayPromptAsync("New task", "Enter description");
            if (!string.IsNullOrWhiteSpace(newTask))
            {
                var button = sender as ImageButton;
                var child = button?.CommandParameter as ChildrenInfo;

                if (child != null)
                {
                    AddNewChildTasks(child.Name,newTask);
                   
                }
                 }
                  }

        private async void AddNewChildTasks(string name, string newTask)
        {
            await App.MyDatabase.CreateChildrenTask(new ChildrenTasks
            {
                ChildName = name,
                Description = newTask,
                IsDone = false

            });
            await Navigation.PopAsync();
        }

        async void childrenList_ItemSelected(object sender, SelectedItemChangedEventArgs e)
        {
            var children = e.SelectedItem as ChildrenInfo;
            var childrenPage = new childrenTaskInfo();
            childrenPage.BindingContext = children;
            await Navigation.PushAsync(childrenPage);
        }

        async void childrenList_ItemTapped(object sender, ItemTappedEventArgs e)
        {
            var children = e.Item as ChildrenInfo;
            var childrenPage = new childrenTaskInfo();
            childrenPage.BindingContext = children;
            await Navigation.PushAsync(childrenPage);

        }

        private async void ToolbarItem_Clicked(object sender, EventArgs e)
        {
            string name = await DisplayPromptAsync("Please add new name", "add name");

            if (string.IsNullOrWhiteSpace(name))
            {
                await DisplayAlert("Invalid", "Blank or incorrect", "OK");
                return;
            }

            FileResult result = null;

            try
            {
                result = await MediaPicker.PickPhotoAsync();
            }
            catch (FeatureNotSupportedException fnsEx)
            {
                await DisplayAlert("Error", "This feature is not supported on your device.", "OK");
                return;
            }
            catch (PermissionException pEx)
            {
                await DisplayAlert("Permission Denied", "You must grant photo access permissions.", "OK");
                return;
            }
            catch (Exception ex)
            {
                await DisplayAlert("Error", "Something went wrong: " + ex.Message, "OK");
                return;
            }

            if (result == null)
            {
                await DisplayAlert("Cancelled", "No image was selected", "OK");
                return;
            }

            string imagePath = result.FullPath;

            await App.MyDatabase.CreateChildrenInfo(new ChildrenInfo
            {
                Name = name,
                Image = imagePath
            });

            await Navigation.PopAsync(); 
        }


        private async void AddNewChild(string name)
        {
            await App.MyDatabase.CreateChildrenInfo(new ChildrenInfo
            {
                Name = name,
             
            });
            await Navigation.PopAsync();

        }

        private async void SwipeItem_delete(object sender, EventArgs e)
        {
            var swipeItem = sender as SwipeItem;
            var NameToDelete = swipeItem?.BindingContext as ChildrenInfo;
            try
            {
                await App.MyDatabase.DeletChildrenInfo(NameToDelete);

                
                childrenList.ItemsSource = await App.MyDatabase.readChildrenInfo();
            }
            catch (Exception ex)
            {
                await DisplayAlert("Error", "Something went wrong: " + ex.Message, "OK");
            }
        }

       
    }
}