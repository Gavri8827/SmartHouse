﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using SmartHouse.familyClass.childrenInfo;
using SmartHouse.familyClass.childrenTasks;
using Xamarin.Forms;
using Xamarin.Forms.Xaml;

namespace SmartHouse.familyClass
{
    [XamlCompilation(XamlCompilationOptions.Compile)]
    public partial class childrenTaskInfo : ContentPage
    {

        public childrenTaskInfo()
        {
            InitializeComponent();

        }

        protected override async void OnAppearing()
        {
            try
            {
                base.OnAppearing();
                ChildrenTaskList.ItemsSource = await App.MyDatabase.GetTasksByChildAsync(name.Text);
            }
            catch { }

        }

        private async void SwipeItem_delete(object sender, EventArgs e)
        {
            var swipeItem = sender as SwipeItem;
            var taskToDelete = swipeItem?.BindingContext as ChildrenTasks;
            try
            {
                await App.MyDatabase.DeletChildrenTask(taskToDelete);

                // רענון הרשימה אחרי מחיקה
                ChildrenTaskList.ItemsSource = await App.MyDatabase.GetTasksByChildAsync(taskToDelete.ChildName);
            }
            catch (Exception ex)
            {
                await DisplayAlert("Error", "Something went wrong: " + ex.Message, "OK");
            }

        }

        private async void SwipeItem_Invoked_1(object sender, EventArgs e)
        {
            var swipeItem = sender as SwipeItem;
            var taskToEdit = swipeItem?.BindingContext as ChildrenTasks;

            if (taskToEdit == null)
            {
                await DisplayAlert("Error", "Could not identify the task.", "OK");
                return;
            }

            string oldDescription = taskToEdit.Description;

            string newDescription = await DisplayPromptAsync("Edit Task", "Enter new description:", initialValue: taskToEdit.Description);
            if (string.IsNullOrWhiteSpace(newDescription))
            {
                await DisplayAlert("Invalid", "Description cannot be empty.", "OK");
                return;
            }

            // מחיקה לפי ה-Description הישן
            await App.MyDatabase.DeleteChildrenTaskByDescription(oldDescription);

            // יצירה מחדש עם ערך חדש
            await App.MyDatabase.CreateChildrenTask(new ChildrenTasks
            {
                ChildName = taskToEdit.ChildName,
                Description = newDescription,
                IsDone = taskToEdit.IsDone
            });

            // רענון
            ChildrenTaskList.ItemsSource = await App.MyDatabase.GetTasksByChildAsync(taskToEdit.ChildName);
        }

        private async void CheckBox_isDone(object sender, CheckedChangedEventArgs e)
        {
            if (e.Value) // רק אם סומן כ-true (כלומר המשימה סומנה כבוצעה)
            {
                var checkBox = sender as CheckBox;
                var task = checkBox?.BindingContext as ChildrenTasks;

                if (task != null)
                {
                    // מחיקת המשימה מהמסד
                    await App.MyDatabase.DeletChildrenTask(task);

                    // רענון הרשימה
                    ChildrenTaskList.ItemsSource = await App.MyDatabase.GetTasksByChildAsync(task.ChildName);
                }
            }

        }
    }
}