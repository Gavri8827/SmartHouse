﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using SmartHouse.familyClass.childrenTasks;
using Xamarin.Forms;
using Xamarin.Forms.Xaml;

namespace SmartHouse.shopcClass
{
    [XamlCompilation(XamlCompilationOptions.Compile)]
    public partial class ShopListPage : ContentPage
    {
       
        public ShopListPage()
        {
            InitializeComponent();
          
        }

        protected override async void OnAppearing()
        {
            try
            {
                base.OnAppearing();
                ShopList.ItemsSource = await App.MyDatabase.GetShopList();
            }
            catch { }

        }




        private async void ToolbarItem_Clicked(object sender, EventArgs e)
        {
            string newItem = await DisplayPromptAsync("New item", "Enter description");
            string quantityText = await DisplayPromptAsync("New item", "Enter quantity", keyboard: Keyboard.Numeric);

            if (!string.IsNullOrWhiteSpace(newItem) && !string.IsNullOrWhiteSpace(quantityText))
            {
           
                if (int.TryParse(quantityText, out int quantity))
                {
                    var ShopItem = (new ShopListInfo
                    {
                        Description = newItem,
                        Quantity = quantity.ToString(),
                        IsDone = false
                    });
                    AddNewShopItem(ShopItem);

                   
                }
                else
                {
                    await DisplayAlert("Error", "Quantity must be a number", "OK");
                }
            }
        }

        private async void AddNewShopItem(ShopListInfo shopList)
        {
            await App.MyDatabase.CreateShopList(shopList);
            
            await Navigation.PopAsync();
        }

        private void SwipeItem_Invoked(object sender, EventArgs e)
        {

        }

        private void SwipeItem_Invoked_1(object sender, EventArgs e)
        {

        }
    }
}