﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using Xamarin.Forms;
using Xamarin.Forms.Xaml;

namespace SmartHouse.shopcClass
{
    [XamlCompilation(XamlCompilationOptions.Compile)]
    public partial class InsertShopItem : ContentPage
    {
        public InsertShopItem()
        {
            InitializeComponent();
        }
    }
}